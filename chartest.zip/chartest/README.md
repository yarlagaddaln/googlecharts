A simple tutorial on how to get started with visualizing data in 
Angular js using Google Chart API. Part 4
