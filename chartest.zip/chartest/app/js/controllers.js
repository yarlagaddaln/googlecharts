
/* Controllers */
google.load('visualization', '1', {packages:['corechart']});
google.setOnLoadCallback(function () {
    angular.bootstrap(document.body, ['myApp']);
});
angular.module('myApp.controllers', []).
  controller('MyCtrl1', ['$scope',function($scope) {
	
        var chart = {};
        chart.options = {
         hAxis: {
            format: 'M/d/yy',
            gridlines: {count: 15}
          }
      }

	$scope.chartTypes = [
            { typeName: 'overallsales', typeValue: '1' },
            { typeName: 'overallorders', typeValue: '2' },
            { typeName: 'pageviews', typeValue: '3' },
            { typeName: 'clickThruRate', typeValue: '4' }
            ];
	$scope.selectType = function (type) {
        	$scope.chart.type = type.typeValue;
		      $scope.chart.typeName = type.typeName;
          $scope.getdata($scope.chart.type); 
    	}
    $scope.getdata = function (chartype){
if(chartype ==1){
  var data = new google.visualization.DataTable();
      data.addColumn('date', 'Date');
      data.addColumn('number', 'overallsales');
      data.addRows([
        [new Date(2016, 4, 27), 11.575086019490813],  
        [new Date(2016, 4, 28), 11.057877730829555],  
        [new Date(2016, 4, 29), 10.769637784623608],
        [new Date(2016, 4, 30), 11.793559308371288],
        [new Date(2016, 5, 01), 11.906171613821066],
        [new Date(2016, 5, 02), 11.618584711166937],
        [new Date(2016, 5, 03), 11.816696070335519],
        [new Date(2016, 5, 04), 11.348390339421794]
      ]);
      


    chart.data = data;
    }
    else if(chartype ==2){
      var data = new google.visualization.DataTable();
      data.addColumn('date', 'Date');
      data.addColumn('number', 'overallorders');
      data.addRows([
        [new Date(2016, 4, 27), 14274],  
        [new Date(2016, 4, 28), 13279],  
        [new Date(2016, 4, 29), 15378],
        [new Date(2016, 4, 30), 16934],
        [new Date(2016, 5, 01), 16156],
        [new Date(2016, 5, 02), 16097],
        [new Date(2016, 5, 03), 15928],
        [new Date(2016, 5, 04), 13465]
      ]);

    chart.data = data;

    }
    else if(chartype ==3){
      var data = new google.visualization.DataTable();
       data.addColumn('date', 'Date');
      data.addColumn('number', 'pageViews');
      data.addRows([
        [new Date(2016, 4, 27), 672522],  
        [new Date(2016, 4, 28), 700062],  
        [new Date(2016, 4, 29), 733293],
        [new Date(2016, 4, 30), 744330],
        [new Date(2016, 5, 01), 721189],
        [new Date(2016, 5, 02), 732430],
        [new Date(2016, 5, 03), 754441],
        [new Date(2016, 5, 04), 688406]
      ]);

    chart.data = data;

    }
    else if(chartype ==4){
      var data = new google.visualization.DataTable();
       data.addColumn('date', 'Date');
      data.addColumn('number', 'clickThruRate');
      data.addRows([
        [new Date(2016, 4, 27), 11.575086019490813],  
        [new Date(2016, 4, 28), 11.057877730829555],  
        [new Date(2016, 4, 29), 10.769637784623608],
        [new Date(2016, 4, 30), 11.793559308371288],
        [new Date(2016, 5, 01), 11.906171613821066],
        [new Date(2016, 5, 02), 11.618584711166937],
        [new Date(2016, 5, 03), 11.816696070335519],
        [new Date(2016, 5, 04), 11.348390339421794]
      ]);

    chart.data = data;

    }

    }
        
       
        chart.type = $scope.chartTypes[0].typeValue;
        chart.typeName = $scope.chartTypes[0].typeName;
        $scope.chartType = $scope.chartTypes[0];
        $scope.chart = chart;
 // loading the 1st chart by the default value for now
var init = function () {
   $scope.getdata(1);
};
init();
        
  }]);
 
  

